import { Switch, Route, Router as WouterRouter, Link, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import IOSSetup from "@/pages/IOSSetup";
import { Activity, Smartphone } from "lucide-react";

const queryClient = new QueryClient();

function Nav() {
  const [location] = useLocation();
  const links = [
    { path: "/", label: "Dashboard", icon: <Activity className="w-4 h-4" /> },
    { path: "/ios", label: "iOS Setup", icon: <Smartphone className="w-4 h-4" /> },
  ];
  return (
    <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 flex items-center gap-1 h-10">
        {links.map((link) => {
          const active = location === link.path;
          return (
            <Link
              key={link.path}
              href={link.path}
              data-testid={`nav-${link.label.toLowerCase().replace(" ", "-")}`}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[11px] font-bold uppercase tracking-wider transition-colors ${
                active
                  ? "bg-primary/10 text-primary border border-primary/30"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              }`}
            >
              {link.icon}
              {link.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

function Router() {
  return (
    <>
      <Nav />
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/ios" component={IOSSetup} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary selection:text-primary-foreground dark">
            <Router />
          </div>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
