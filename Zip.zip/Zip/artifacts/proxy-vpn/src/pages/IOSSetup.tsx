import { useState, useEffect } from "react";
import QRCode from "react-qr-code";
import {
  Smartphone, Download, Copy, Check, Wifi, ChevronRight,
  ShieldCheck, Globe, Signal, Power, StopCircle, Info,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface IOSInfo {
  proxyHost: string;
  proxyPort: number;
  socks5Port: number;
  pacUrl: string;
  configUrl: string;
  socks5Stats: { running: boolean; port: number | null; connections: number };
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button
      onClick={copy}
      data-testid={`copy-${label}`}
      className="inline-flex items-center gap-1 text-primary hover:text-primary/80 transition-colors ml-2 flex-shrink-0"
    >
      {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
      <span className="text-[10px] uppercase tracking-wider">{copied ? "Copied" : "Copy"}</span>
    </button>
  );
}

function InfoRow({ label, value, copy }: { label: string; value: string; copy?: boolean }) {
  return (
    <div className="flex items-center justify-between bg-background/60 rounded px-3 py-2.5 border border-border/60">
      <div>
        <p className="text-[10px] uppercase text-muted-foreground tracking-wider">{label}</p>
        <code className="text-sm text-foreground font-bold">{value}</code>
      </div>
      {copy && <CopyButton text={value} label={label.toLowerCase().replace(/\s/g, "-")} />}
    </div>
  );
}

function StepCard({ num, icon, title, desc }: { num: string; icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div data-testid={`step-${num}`} className="flex items-start gap-3 p-3 rounded-md bg-secondary/30 border border-border/50">
      <div className="flex-shrink-0 w-8 h-8 rounded-sm bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
        {icon}
      </div>
      <div className="flex-1 min-w-0 space-y-0.5">
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-primary/60 font-mono">{num}</span>
          <p className="text-xs font-bold text-foreground uppercase tracking-wide">{title}</p>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

type Tab = "wifi" | "cellular";
type AppGuide = "shadowrocket" | "potatso";

export default function IOSSetup() {
  const [info, setInfo] = useState<IOSInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>("wifi");
  const [appGuide, setAppGuide] = useState<AppGuide>("shadowrocket");
  const [socks5Loading, setSocks5Loading] = useState(false);

  const base = import.meta.env.BASE_URL.replace(/\/$/, "");

  const fetchInfo = () => {
    fetch(`${base}/api/ios/info`)
      .then((r) => r.json())
      .then((d) => setInfo(d))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchInfo();
    const t = setInterval(fetchInfo, 4000);
    return () => clearInterval(t);
  }, []);

  const toggleSocks5 = async () => {
    if (!info) return;
    setSocks5Loading(true);
    const action = info.socks5Stats.running ? "stop" : "start";
    await fetch(`${base}/api/ios/socks5/${action}`, { method: "POST" });
    await new Promise((r) => setTimeout(r, 500));
    fetchInfo();
    setSocks5Loading(false);
  };

  const socks5Running = info?.socks5Stats.running ?? false;

  const wifiSteps = [
    { num: "01", icon: <Wifi className="w-4 h-4" />, title: "เปิดการตั้งค่า WiFi", desc: "Settings → Wi-Fi → แตะชื่อเครือข่ายที่เชื่อมต่ออยู่" },
    { num: "02", icon: <Globe className="w-4 h-4" />, title: "Configure Proxy", desc: "เลื่อนลงแตะ \"Configure Proxy\"" },
    { num: "03", icon: <ChevronRight className="w-4 h-4" />, title: "เลือก Manual", desc: "แตะ \"Manual\" แล้วกรอก Server และ Port ด้านบน" },
    { num: "04", icon: <ShieldCheck className="w-4 h-4" />, title: "กด Save", desc: "แตะ Save มุมขวาบน แล้วเปิดเกมได้เลย" },
  ];

  const shadowrocketSteps = [
    { num: "01", icon: <Download className="w-4 h-4" />, title: "ติดตั้ง Shadowrocket", desc: "ดาวน์โหลดจาก App Store — ค้นหา \"Shadowrocket\" (฿99)" },
    { num: "02", icon: <Power className="w-4 h-4" />, title: "เปิด SOCKS5 Proxy", desc: "กดปุ่ม \"เปิด SOCKS5\" ด้านซ้าย แล้วรอสถานะ RUNNING" },
    { num: "03", icon: <Globe className="w-4 h-4" />, title: "เพิ่ม Server", desc: "เปิด Shadowrocket → แตะ '+' มุมขวาบน → Type: SOCKS5 → ใส่ Host และ Port 18081 → Save" },
    { num: "04", icon: <ShieldCheck className="w-4 h-4" />, title: "เปิดการเชื่อมต่อ", desc: "แตะ Toggle ปุ่มใหญ่ด้านบน → เลือก Global (ส่งทุก traffic) หรือ Rule (เลือกเฉพาะบาง domain)" },
  ];

  const potatsoSteps = [
    { num: "01", icon: <Download className="w-4 h-4" />, title: "ติดตั้ง Potatso Lite", desc: "ดาวน์โหลดจาก App Store — ค้นหา \"Potatso Lite\" (ฟรี)" },
    { num: "02", icon: <Power className="w-4 h-4" />, title: "เปิด SOCKS5 Proxy", desc: "กดปุ่ม \"เปิด SOCKS5\" ด้านซ้าย แล้วรอสถานะ RUNNING" },
    { num: "03", icon: <Globe className="w-4 h-4" />, title: "เพิ่ม Proxy Server", desc: "เปิดแอป → แตะ '+' → เลือก \"Proxy\" → Protocol: SOCKS5 → กรอก Host และ Port 18081 → กด Done" },
    { num: "04", icon: <ChevronRight className="w-4 h-4" />, title: "สร้าง Rule", desc: "แตะ 'Rule' ด้านล่าง → '+' → เลือก Proxy ที่เพิ่งสร้าง → Match: domain ของเกม หรือเลือก ALL เพื่อ route ทุก traffic" },
    { num: "05", icon: <ShieldCheck className="w-4 h-4" />, title: "เปิดการเชื่อมต่อ", desc: "กลับหน้าหลัก → แตะปุ่ม Connect → iOS จะขอสิทธิ์ VPN → Allow → รอสถานะ Connected" },
  ];

  return (
    <div className="min-h-screen bg-background p-6 space-y-5 max-w-5xl mx-auto font-mono">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border pb-4">
        <Smartphone className="w-7 h-7 text-primary" />
        <h1 className="text-xl font-bold tracking-tight uppercase text-primary">iOS Setup</h1>
        <Badge variant="outline" className="border-primary/40 text-primary/70 text-[10px] uppercase">
          iPhone / iPad
        </Badge>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <button
          data-testid="tab-wifi"
          onClick={() => setTab("wifi")}
          className={`flex items-center gap-2 px-4 py-2 rounded text-xs font-bold uppercase tracking-wider border transition-colors ${
            tab === "wifi"
              ? "bg-primary/10 text-primary border-primary/40"
              : "text-muted-foreground border-border/50 hover:text-foreground hover:bg-secondary/40"
          }`}
        >
          <Wifi className="w-3.5 h-3.5" />
          WiFi
        </button>
        <button
          data-testid="tab-cellular"
          onClick={() => setTab("cellular")}
          className={`flex items-center gap-2 px-4 py-2 rounded text-xs font-bold uppercase tracking-wider border transition-colors ${
            tab === "cellular"
              ? "bg-primary/10 text-primary border-primary/40"
              : "text-muted-foreground border-border/50 hover:text-foreground hover:bg-secondary/40"
          }`}
        >
          <Signal className="w-3.5 h-3.5" />
          Cellular / มือถือ
        </button>
      </div>

      {/* ── WiFi Tab ── */}
      {tab === "wifi" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Left */}
          <div className="space-y-4">
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  PAC URL — สแกนด้วย iPhone
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  สแกน QR นี้บน iPhone → Settings → Wi-Fi → Configure Proxy → Automatic
                </p>
                <div className="flex justify-center p-5 bg-white rounded-lg border border-border">
                  {loading ? (
                    <div className="w-[180px] h-[180px] flex items-center justify-center text-muted-foreground text-xs uppercase">Loading...</div>
                  ) : info ? (
                    <QRCode value={info.pacUrl} size={180} fgColor="#000000" bgColor="#ffffff" />
                  ) : (
                    <div className="w-[180px] h-[180px] flex items-center justify-center text-muted-foreground text-xs uppercase">Error</div>
                  )}
                </div>
                {info && (
                  <div className="flex items-center bg-secondary/40 rounded px-3 py-2 border border-border/60">
                    <code className="text-[10px] text-primary flex-1 break-all leading-relaxed">{info.pacUrl}</code>
                    <CopyButton text={info.pacUrl} label="pac-url" />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  Configuration Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  ดาวน์โหลดไฟล์ .mobileconfig แล้วเปิดจาก Safari บน iPhone
                </p>
                {info && (
                  <a
                    href={info.configUrl}
                    data-testid="download-mobileconfig"
                    className="flex items-center justify-center gap-2 w-full py-2.5 rounded-md border border-primary/30 bg-primary/5 text-primary text-xs font-bold uppercase tracking-wider hover:bg-primary/10 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    Download GameProxy.mobileconfig
                  </a>
                )}
                <p className="text-[10px] text-muted-foreground/60 leading-relaxed">
                  หลังติดตั้ง: Settings → General → VPN &amp; Device Management → Install
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Right */}
          <div className="space-y-4">
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary">ข้อมูล Proxy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <InfoRow label="Server (Host)" value={loading ? "..." : info?.proxyHost ?? "—"} copy={!!info} />
                <InfoRow label="Port" value="18080" copy />
                <InfoRow label="Type" value="HTTP" />
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary">ตั้งค่าแบบ Manual</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {wifiSteps.map((s) => (
                  <StepCard key={s.num} {...s} />
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* ── Cellular Tab ── */}
      {tab === "cellular" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Left */}
          <div className="space-y-4">
            {/* SOCKS5 Status + Toggle */}
            <Card className={`border transition-all duration-300 ${socks5Running ? "border-primary/50 shadow-[0_0_12px_rgba(0,240,255,0.08)]" : "border-border"}`}>
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Signal className="w-4 h-4" />
                    SOCKS5 Proxy
                  </div>
                  {socks5Running
                    ? <Badge className="bg-primary/10 text-primary border-primary/40 border text-[10px] animate-pulse">RUNNING</Badge>
                    : <Badge variant="outline" className="border-destructive/40 text-destructive/80 text-[10px]">STOPPED</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  SOCKS5 รองรับทั้ง WiFi และ Cellular — ใช้กับแอป Shadowrocket หรือ Potatso Lite บน iPhone
                </p>
                <button
                  data-testid="toggle-socks5"
                  onClick={toggleSocks5}
                  disabled={socks5Loading}
                  className={`flex items-center justify-center gap-2 w-full py-2.5 rounded-md border text-xs font-bold uppercase tracking-wider transition-colors ${
                    socks5Running
                      ? "bg-destructive/10 text-destructive border-destructive/30 hover:bg-destructive/20"
                      : "bg-primary/10 text-primary border-primary/30 hover:bg-primary/20"
                  } disabled:opacity-50`}
                >
                  {socks5Running
                    ? <><StopCircle className="w-4 h-4" /> ปิด SOCKS5</>
                    : <><Power className="w-4 h-4" /> เปิด SOCKS5</>}
                </button>

                {socks5Running && info && (
                  <div className="space-y-2 pt-1">
                    <InfoRow label="Server (Host)" value={info.proxyHost} copy />
                    <InfoRow label="Port" value={String(info.socks5Port)} copy />
                    <InfoRow label="Type" value="SOCKS5" />
                    <InfoRow label="Auth" value="None (No Password)" />
                    {info.socks5Stats.connections > 0 && (
                      <InfoRow label="Active Connections" value={String(info.socks5Stats.connections)} />
                    )}
                  </div>
                )}

                {!socks5Running && (
                  <div className="flex items-start gap-2 rounded bg-yellow-500/5 border border-yellow-500/20 px-3 py-2.5">
                    <Info className="w-3.5 h-3.5 text-yellow-400/80 flex-shrink-0 mt-0.5" />
                    <p className="text-[11px] text-yellow-400/70 leading-relaxed">
                      เปิด SOCKS5 ก่อน แล้วค่อยตั้งค่าในแอป Shadowrocket
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* QR for Shadowrocket */}
            {socks5Running && info && (
              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
                    <Smartphone className="w-4 h-4" />
                    QR สำหรับ Shadowrocket
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    สแกน QR นี้ใน Shadowrocket ('+' → Scan QR) เพื่อเพิ่ม server อัตโนมัติ
                  </p>
                  <div className="flex justify-center p-4 bg-white rounded-lg border border-border">
                    <QRCode
                      value={`socks5://${info.proxyHost}:${info.socks5Port}`}
                      size={160}
                      fgColor="#000000"
                      bgColor="#ffffff"
                    />
                  </div>
                  <div className="flex items-center bg-secondary/40 rounded px-3 py-2 border border-border/60">
                    <code className="text-[10px] text-primary flex-1 break-all">
                      socks5://{info.proxyHost}:{info.socks5Port}
                    </code>
                    <CopyButton text={`socks5://${info.proxyHost}:${info.socks5Port}`} label="socks5-url" />
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right */}
          <div className="space-y-4">
            {/* App selector */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary">เลือกแอปที่ใช้</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {[
                  { id: "shadowrocket" as AppGuide, name: "Shadowrocket", price: "฿99", note: "แนะนำ — Global mode, QR import" },
                  { id: "potatso" as AppGuide, name: "Potatso Lite", price: "ฟรี", note: "ฟรี — Rule-based, ตั้งค่าเองได้" },
                ].map((app) => (
                  <button
                    key={app.id}
                    data-testid={`app-guide-${app.id}`}
                    onClick={() => setAppGuide(app.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded border text-left transition-colors ${
                      appGuide === app.id
                        ? "border-primary/50 bg-primary/10"
                        : "border-border/50 bg-secondary/20 hover:border-border hover:bg-secondary/40"
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-bold text-foreground">{app.name}</p>
                        {appGuide === app.id && (
                          <Badge className="text-[9px] bg-primary/20 text-primary border-primary/30 border">เลือกอยู่</Badge>
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground">{app.note}</p>
                    </div>
                    <span className="text-xs font-bold text-primary flex-shrink-0">{app.price}</span>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Steps for selected app */}
            <Card className="border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-primary">
                  ขั้นตอนตั้งค่า {appGuide === "shadowrocket" ? "Shadowrocket" : "Potatso Lite"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {(appGuide === "shadowrocket" ? shadowrocketSteps : potatsoSteps).map((s) => (
                  <StepCard key={s.num} {...s} />
                ))}
              </CardContent>
            </Card>

            {appGuide === "potatso" && (
              <div className="rounded-md border border-primary/20 bg-primary/5 px-4 py-3">
                <p className="text-[11px] text-primary/80 leading-relaxed">
                  <span className="font-bold uppercase tracking-wider text-primary">Potatso Lite: </span>
                  ฟรี แต่ใน Rule step ต้องสร้าง Rule Set ด้วย — ถ้าต้องการส่ง traffic ทุกอย่าง ให้เพิ่ม Rule แบบ "Final → Proxy"
                </p>
              </div>
            )}

            <div className="rounded-md border border-yellow-500/20 bg-yellow-500/5 px-4 py-3">
              <p className="text-[11px] text-yellow-400/80 leading-relaxed">
                <span className="font-bold uppercase tracking-wider text-yellow-400">หมายเหตุ: </span>
                ต้อง Deploy แอปนี้ก่อนเพื่อให้ iPhone เข้าถึงจากอินเทอร์เน็ตได้ — ในโหมด dev จะเชื่อมต่อได้เฉพาะในเครือข่ายเดียวกัน
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
