import React, { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetProxyStatus,
  getGetProxyStatusQueryKey,
  useStartProxy,
  useStopProxy,
  useToggleVpn,
  useGetProxyLogs,
  getGetProxyLogsQueryKey,
  useClearProxyLogs,
  useSetStealthMode,
  useGetLogSettings,
  getGetLogSettingsQueryKey,
} from "@workspace/api-client-react";
import { Activity, Power, Shield, StopCircle, ArrowRightLeft, Clock, Zap, Globe, HardDrive, Cpu, Fingerprint, Trash2, EyeOff, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";

function formatBytes(bytes: number) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatUptime(startedAt: string | null) {
  if (!startedAt) return "00:00:00";
  const start = new Date(startedAt).getTime();
  const now = Date.now();
  const diff = now - start;
  
  const h = Math.floor(diff / (1000 * 60 * 60));
  const m = Math.floor((diff / (1000 * 60)) % 60);
  const s = Math.floor((diff / 1000) % 60);
  
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [domain, setDomain] = useState("game.server.local");
  const [port, setPort] = useState("8080");
  const [uptime, setUptime] = useState("00:00:00");

  const { data: status } = useGetProxyStatus({
    query: {
      refetchInterval: 2000,
      queryKey: getGetProxyStatusQueryKey()
    }
  });

  const { data: logs = [] } = useGetProxyLogs({
    query: {
      refetchInterval: status?.proxyRunning ? 3000 : false,
      queryKey: getGetProxyLogsQueryKey()
    }
  });

  const startProxy = useStartProxy();
  const stopProxy = useStopProxy();
  const toggleVpn = useToggleVpn();
  const clearLogs = useClearProxyLogs();
  const setStealthMode = useSetStealthMode();

  const { data: logSettings } = useGetLogSettings({
    query: { refetchInterval: 3000, queryKey: getGetLogSettingsQueryKey() }
  });

  const isStealthy = logSettings?.stealthMode ?? false;

  const handleClearLogs = () => {
    clearLogs.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetProxyLogsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLogSettingsQueryKey() });
      }
    });
  };

  const handleToggleStealth = (checked: boolean) => {
    setStealthMode.mutate(
      { data: { enabled: checked } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetLogSettingsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetProxyLogsQueryKey() });
        }
      }
    );
  };

  useEffect(() => {
    if (status?.startedAt && status.proxyRunning) {
      const interval = setInterval(() => {
        setUptime(formatUptime(status.startedAt!));
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setUptime("00:00:00");
    }
  }, [status?.startedAt, status?.proxyRunning]);

  useEffect(() => {
    if (status && status.domain) setDomain(status.domain);
    if (status && status.port) setPort(status.port.toString());
  }, [status?.domain, status?.port]);

  const handleStart = () => {
    startProxy.mutate(
      { data: { domain, port: parseInt(port, 10), vpnEnabled: status?.vpnEnabled || false } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetProxyStatusQueryKey() });
        }
      }
    );
  };

  const handleStop = () => {
    stopProxy.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetProxyStatusQueryKey() });
      }
    });
  };

  const handleToggleVpn = (checked: boolean) => {
    toggleVpn.mutate(
      { data: { enabled: checked } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetProxyStatusQueryKey() });
        }
      }
    );
  };

  const isRunning = status?.proxyRunning;
  const isVpnOn = status?.vpnEnabled;

  return (
    <div className="min-h-screen bg-background p-6 space-y-6 max-w-7xl mx-auto font-mono">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border pb-4">
        <div className="flex items-center space-x-3 text-primary">
          <Activity className="w-8 h-8" />
          <h1 className="text-2xl font-bold tracking-tight uppercase">PROXY & VPN MANAGER</h1>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Status</span>
            {isRunning ? (
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary animate-pulse">CONNECTED</Badge>
            ) : (
              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive">DISCONNECTED</Badge>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Controls */}
        <div className="space-y-6 lg:col-span-1">
          {/* Proxy Config */}
          <Card className="border-border bg-card">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-bold uppercase tracking-wider flex items-center space-x-2 text-primary">
                <Cpu className="w-4 h-4" />
                <span>INTERCEPT CONFIG</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-xs uppercase text-muted-foreground">Target Domain / IP</Label>
                <div className="relative">
                  <Globe className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                  <Input 
                    disabled={isRunning}
                    value={domain} 
                    onChange={(e) => setDomain(e.target.value)}
                    className="pl-9 font-mono bg-background/50 border-border focus:border-primary"
                    placeholder="game.server.local"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-xs uppercase text-muted-foreground">Target Port</Label>
                <div className="relative">
                  <HardDrive className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                  <Input 
                    disabled={isRunning}
                    type="number"
                    value={port} 
                    onChange={(e) => setPort(e.target.value)}
                    className="pl-9 font-mono bg-background/50 border-border focus:border-primary"
                    placeholder="8080"
                  />
                </div>
              </div>
              
              <div className="pt-2">
                {isRunning ? (
                  <Button 
                    onClick={handleStop} 
                    disabled={stopProxy.isPending}
                    className="w-full bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground border border-destructive/20 font-bold uppercase tracking-wider"
                  >
                    <StopCircle className="w-4 h-4 mr-2" />
                    HALT PROXY
                  </Button>
                ) : (
                  <Button 
                    onClick={handleStart} 
                    disabled={startProxy.isPending || !domain || !port}
                    className="w-full bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground border border-primary/20 font-bold uppercase tracking-wider"
                  >
                    <Power className="w-4 h-4 mr-2" />
                    INITIALIZE
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* VPN Toggle */}
          <Card className={`border ${isVpnOn ? 'border-primary shadow-[0_0_15px_rgba(0,240,255,0.1)]' : 'border-border'} transition-all duration-300`}>
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-bold uppercase tracking-wider flex items-center justify-between text-primary">
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4" />
                  <span>VPN TUNNEL</span>
                </div>
                {isVpnOn && <Badge className="bg-primary text-primary-foreground text-[10px]">SECURED</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Route Traffic</p>
                  <p className="text-xs text-muted-foreground">Force all connections through VPN</p>
                </div>
                <Switch 
                  checked={isVpnOn || false}
                  onCheckedChange={handleToggleVpn}
                  disabled={toggleVpn.isPending}
                  className="data-[state=checked]:bg-primary"
                />
              </div>
            </CardContent>
          </Card>

          {/* Live Stats */}
          <Card className="border-border">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-bold uppercase tracking-wider flex items-center space-x-2 text-primary">
                <Zap className="w-4 h-4" />
                <span>TELEMETRY</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="space-y-1 p-3 bg-secondary/50 rounded-md border border-border/50">
                <p className="text-[10px] uppercase text-muted-foreground tracking-wider flex items-center"><ArrowRightLeft className="w-3 h-3 mr-1"/> DATA IN</p>
                <p className="text-lg font-bold text-foreground">{formatBytes(status?.bytesIn || 0)}</p>
              </div>
              <div className="space-y-1 p-3 bg-secondary/50 rounded-md border border-border/50">
                <p className="text-[10px] uppercase text-muted-foreground tracking-wider flex items-center"><ArrowRightLeft className="w-3 h-3 mr-1"/> DATA OUT</p>
                <p className="text-lg font-bold text-foreground">{formatBytes(status?.bytesOut || 0)}</p>
              </div>
              <div className="space-y-1 p-3 bg-secondary/50 rounded-md border border-border/50">
                <p className="text-[10px] uppercase text-muted-foreground tracking-wider flex items-center"><Activity className="w-3 h-3 mr-1"/> REQUESTS</p>
                <p className="text-lg font-bold text-foreground">{status?.requestCount || 0}</p>
              </div>
              <div className="space-y-1 p-3 bg-secondary/50 rounded-md border border-border/50">
                <p className="text-[10px] uppercase text-muted-foreground tracking-wider flex items-center"><Clock className="w-3 h-3 mr-1"/> UPTIME</p>
                <p className="text-lg font-bold text-foreground">{uptime}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Logs */}
        <div className="lg:col-span-2 flex flex-col h-[calc(100vh-100px)]">
          <Card className="border-border flex-1 flex flex-col overflow-hidden">
            <CardHeader className="pb-4 border-b border-border bg-card/50">
              <div className="flex items-center justify-between gap-3">
                <CardTitle className="text-sm font-bold uppercase tracking-wider flex items-center space-x-2 text-primary shrink-0">
                  <Fingerprint className="w-4 h-4" />
                  <span>TRAFFIC LOGS</span>
                  {isStealthy && (
                    <span className="ml-1 text-[10px] font-bold uppercase tracking-wider text-destructive border border-destructive/40 bg-destructive/10 px-1.5 py-0.5 rounded animate-pulse">
                      STEALTH
                    </span>
                  )}
                </CardTitle>
                <div className="flex items-center gap-2">
                  {/* Stealth Mode */}
                  <div
                    data-testid="stealth-mode-toggle"
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border cursor-pointer select-none transition-colors ${
                      isStealthy
                        ? "border-destructive/50 bg-destructive/10 text-destructive"
                        : "border-border/50 bg-secondary/30 text-muted-foreground hover:text-foreground hover:border-border"
                    }`}
                    onClick={() => handleToggleStealth(!isStealthy)}
                    title={isStealthy ? "Stealth on — ไม่มีการบันทึก log" : "เปิด Stealth mode"}
                  >
                    {isStealthy ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span className="text-[10px] font-bold uppercase tracking-wider hidden sm:block">
                      {isStealthy ? "Stealth On" : "Stealth"}
                    </span>
                  </div>
                  {/* Clear Logs */}
                  <button
                    data-testid="clear-logs-button"
                    onClick={handleClearLogs}
                    disabled={clearLogs.isPending || logs.length === 0}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded border border-border/50 bg-secondary/30 text-muted-foreground hover:text-destructive hover:border-destructive/40 hover:bg-destructive/5 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    title="ล้างประวัติทั้งหมด"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-bold uppercase tracking-wider hidden sm:block">Clear</span>
                  </button>
                  <span className="text-[10px] text-muted-foreground hidden md:block">Auto-refresh: 3s</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-hidden relative">
              <ScrollArea className="h-full">
                <Table>
                  <TableHeader className="bg-secondary/30 sticky top-0 backdrop-blur-md">
                    <TableRow className="border-border hover:bg-transparent">
                      <TableHead className="w-[100px] text-xs uppercase tracking-wider">Method</TableHead>
                      <TableHead className="w-[80px] text-xs uppercase tracking-wider">Status</TableHead>
                      <TableHead className="text-xs uppercase tracking-wider">Target URL</TableHead>
                      <TableHead className="text-right text-xs uppercase tracking-wider">Size</TableHead>
                      <TableHead className="text-right text-xs uppercase tracking-wider">Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="h-32 text-center text-muted-foreground text-sm uppercase tracking-widest border-border">
                          No traffic intercepted
                        </TableCell>
                      </TableRow>
                    ) : (
                      logs.map((log) => (
                        <TableRow key={log.id} className="border-border hover:bg-secondary/20 transition-colors">
                          <TableCell className="font-medium">
                            <Badge variant="outline" className="text-[10px] uppercase tracking-wider font-mono border-primary/30 text-primary bg-primary/5">
                              {log.method}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant="outline" 
                              className={`text-[10px] font-mono
                                ${log.statusCode >= 200 && log.statusCode < 300 ? 'border-green-500/50 text-green-400 bg-green-500/10' : ''}
                                ${log.statusCode >= 300 && log.statusCode < 400 ? 'border-yellow-500/50 text-yellow-400 bg-yellow-500/10' : ''}
                                ${log.statusCode >= 400 ? 'border-destructive/50 text-destructive bg-destructive/10' : ''}
                              `}
                            >
                              {log.statusCode}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-[300px] truncate text-xs text-muted-foreground" title={log.url}>
                            {log.url}
                          </TableCell>
                          <TableCell className="text-right text-xs text-muted-foreground whitespace-nowrap">
                            {formatBytes(log.bytesTransferred || 0)}
                          </TableCell>
                          <TableCell className="text-right text-xs text-muted-foreground whitespace-nowrap">
                            {log.duration || 0}ms
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
              
              {/* Scanline effect overlay */}
              <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(0,240,255,0.03)_1px,transparent_1px)] bg-[size:100%_4px] opacity-20"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
