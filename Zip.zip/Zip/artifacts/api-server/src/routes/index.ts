import { Router, type IRouter } from "express";
import healthRouter from "./health";
import proxyRouter from "./proxy";
import iosRouter from "./ios";

const router: IRouter = Router();

router.use(healthRouter);
router.use(proxyRouter);
router.use("/ios", iosRouter);

export default router;
