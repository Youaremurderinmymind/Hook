import { Router } from "express";
import http from "http";
import https from "https";
import net from "net";
import { randomUUID } from "crypto";
import {
  StartProxyBody,
  ToggleVpnBody,
  SetStealthModeBody,
} from "@workspace/api-zod";

const router = Router();

interface ProxyState {
  running: boolean;
  vpnEnabled: boolean;
  domain: string | null;
  port: number | null;
  proxyPort: number | null;
  startedAt: string | null;
  bytesIn: number;
  bytesOut: number;
  requestCount: number;
  server: http.Server | null;
}

interface LogEntry {
  id: string;
  timestamp: string;
  method: string;
  url: string;
  statusCode: number;
  bytesTransferred: number;
  duration: number;
}

const state: ProxyState = {
  running: false,
  vpnEnabled: false,
  domain: null,
  port: null,
  proxyPort: null,
  startedAt: null,
  bytesIn: 0,
  bytesOut: 0,
  requestCount: 0,
  server: null,
};

const logs: LogEntry[] = [];
const MAX_LOGS = 200;
const PROXY_PORT = 18080;
let stealthMode = false;

function addLog(entry: Omit<LogEntry, "id" | "timestamp">) {
  if (stealthMode) return;
  logs.unshift({
    id: randomUUID(),
    timestamp: new Date().toISOString(),
    ...entry,
  });
  if (logs.length > MAX_LOGS) logs.length = MAX_LOGS;
}

function createProxyServer(targetDomain: string, targetPort: number): http.Server {
  const server = http.createServer((req, res) => {
    if (!req.url) {
      res.writeHead(400);
      res.end("Bad request");
      return;
    }

    const start = Date.now();
    state.requestCount++;

    const options: http.RequestOptions = {
      hostname: targetDomain,
      port: targetPort,
      path: req.url,
      method: req.method,
      headers: {
        ...req.headers,
        host: `${targetDomain}:${targetPort}`,
      },
    };

    const proxyReq = http.request(options, (proxyRes) => {
      res.writeHead(proxyRes.statusCode ?? 200, proxyRes.headers);

      let bytes = 0;
      proxyRes.on("data", (chunk: Buffer) => {
        bytes += chunk.length;
        state.bytesIn += chunk.length;
        res.write(chunk);
      });

      proxyRes.on("end", () => {
        res.end();
        addLog({
          method: req.method ?? "GET",
          url: `http://${targetDomain}:${targetPort}${req.url}`,
          statusCode: proxyRes.statusCode ?? 200,
          bytesTransferred: bytes,
          duration: Date.now() - start,
        });
      });
    });

    proxyReq.on("error", (err) => {
      res.writeHead(502);
      res.end(`Proxy error: ${err.message}`);
      addLog({
        method: req.method ?? "GET",
        url: `http://${targetDomain}:${targetPort}${req.url}`,
        statusCode: 502,
        bytesTransferred: 0,
        duration: Date.now() - start,
      });
    });

    let reqBytes = 0;
    req.on("data", (chunk: Buffer) => {
      reqBytes += chunk.length;
      state.bytesOut += chunk.length;
      proxyReq.write(chunk);
    });

    req.on("end", () => {
      proxyReq.end();
    });
  });

  // Handle CONNECT (HTTPS tunneling)
  server.on("connect", (req, clientSocket, head) => {
    const start = Date.now();
    state.requestCount++;

    const serverSocket = net.connect(targetPort, targetDomain, () => {
      clientSocket.write(
        "HTTP/1.1 200 Connection Established\r\nProxy-agent: GameProxy\r\n\r\n"
      );
      serverSocket.write(head);
      serverSocket.pipe(clientSocket);
      clientSocket.pipe(serverSocket);

      let bytes = 0;
      serverSocket.on("data", (chunk: Buffer) => {
        bytes += chunk.length;
        state.bytesIn += chunk.length;
      });
      clientSocket.on("data", (chunk: Buffer) => {
        state.bytesOut += chunk.length;
      });

      serverSocket.on("end", () => {
        addLog({
          method: "CONNECT",
          url: req.url ?? `${targetDomain}:${targetPort}`,
          statusCode: 200,
          bytesTransferred: bytes,
          duration: Date.now() - start,
        });
      });
    });

    serverSocket.on("error", (err) => {
      clientSocket.write(`HTTP/1.1 502 Bad Gateway\r\n\r\n`);
      clientSocket.end();
      addLog({
        method: "CONNECT",
        url: req.url ?? `${targetDomain}:${targetPort}`,
        statusCode: 502,
        bytesTransferred: 0,
        duration: Date.now() - start,
      });
    });
  });

  return server;
}

// GET /proxy/status
router.get("/proxy/status", (_req, res) => {
  res.json({
    proxyRunning: state.running,
    vpnEnabled: state.vpnEnabled,
    domain: state.domain,
    port: state.port,
    proxyPort: state.running ? state.proxyPort : null,
    startedAt: state.startedAt,
    bytesIn: state.bytesIn,
    bytesOut: state.bytesOut,
    requestCount: state.requestCount,
  });
});

// POST /proxy/start
router.post("/proxy/start", (req, res) => {
  const parsed = StartProxyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body", details: parsed.error.issues });
    return;
  }

  const { domain, port, vpnEnabled } = parsed.data;

  // Stop existing proxy if running
  if (state.server) {
    state.server.close();
    state.server = null;
  }

  const server = createProxyServer(domain, port);

  server.listen(PROXY_PORT, "0.0.0.0", () => {
    state.running = true;
    state.domain = domain;
    state.port = port;
    state.proxyPort = PROXY_PORT;
    state.startedAt = new Date().toISOString();
    state.bytesIn = 0;
    state.bytesOut = 0;
    state.requestCount = 0;
    state.server = server;
    if (vpnEnabled !== undefined) state.vpnEnabled = vpnEnabled;

    res.json({
      proxyRunning: state.running,
      vpnEnabled: state.vpnEnabled,
      domain: state.domain,
      port: state.port,
      proxyPort: state.proxyPort,
      startedAt: state.startedAt,
      bytesIn: state.bytesIn,
      bytesOut: state.bytesOut,
      requestCount: state.requestCount,
    });
  });

  server.on("error", (err: NodeJS.ErrnoException) => {
    if (err.code === "EADDRINUSE") {
      state.running = true;
      state.domain = domain;
      state.port = port;
      state.proxyPort = PROXY_PORT;
      state.startedAt = new Date().toISOString();
      state.bytesIn = 0;
      state.bytesOut = 0;
      state.requestCount = 0;
      state.server = server;
      if (vpnEnabled !== undefined) state.vpnEnabled = vpnEnabled;

      if (!res.headersSent) {
        res.json({
          proxyRunning: state.running,
          vpnEnabled: state.vpnEnabled,
          domain: state.domain,
          port: state.port,
          proxyPort: state.proxyPort,
          startedAt: state.startedAt,
          bytesIn: state.bytesIn,
          bytesOut: state.bytesOut,
          requestCount: state.requestCount,
        });
      }
    } else {
      if (!res.headersSent) {
        res.status(500).json({ error: err.message });
      }
    }
  });
});

// POST /proxy/stop
router.post("/proxy/stop", (_req, res) => {
  if (state.server) {
    state.server.close();
    state.server = null;
  }

  state.running = false;
  state.domain = null;
  state.port = null;
  state.proxyPort = null;
  state.startedAt = null;
  state.bytesIn = 0;
  state.bytesOut = 0;
  state.requestCount = 0;

  res.json({
    proxyRunning: false,
    vpnEnabled: state.vpnEnabled,
    domain: null,
    port: null,
    proxyPort: null,
    startedAt: null,
    bytesIn: 0,
    bytesOut: 0,
    requestCount: 0,
  });
});

// POST /vpn/toggle
router.post("/vpn/toggle", (req, res) => {
  const parsed = ToggleVpnBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body" });
    return;
  }

  state.vpnEnabled = parsed.data.enabled;

  res.json({
    proxyRunning: state.running,
    vpnEnabled: state.vpnEnabled,
    domain: state.domain,
    port: state.port,
    proxyPort: state.running ? state.proxyPort : null,
    startedAt: state.startedAt,
    bytesIn: state.bytesIn,
    bytesOut: state.bytesOut,
    requestCount: state.requestCount,
  });
});

// GET /proxy/logs
router.get("/proxy/logs", (_req, res) => {
  res.json(logs.slice(0, 100));
});

// POST /proxy/logs/clear
router.post("/proxy/logs/clear", (_req, res) => {
  const cleared = logs.length;
  logs.length = 0;
  res.json({ cleared });
});

// POST /proxy/logs/stealth
router.post("/proxy/logs/stealth", (req, res) => {
  const parsed = SetStealthModeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body" });
    return;
  }
  stealthMode = parsed.data.enabled;
  // When enabling stealth, wipe existing logs immediately
  if (stealthMode) logs.length = 0;
  res.json({ stealthMode, logCount: logs.length });
});

// GET /proxy/logs/settings
router.get("/proxy/logs/settings", (_req, res) => {
  res.json({ stealthMode, logCount: logs.length });
});

export default router;
