import { Router } from "express";
import { startSocks5, stopSocks5, getSocks5Stats } from "../lib/socks5";

const router = Router();

// GET /info — connection info for iOS setup
router.get("/info", (req, res) => {
  const host = req.headers["x-forwarded-host"] || req.hostname;
  const protocol = req.headers["x-forwarded-proto"] || "https";
  const proxyPort = 18080;
  const socks5Port = 18081;
  const baseUrl = `${protocol}://${host}`;

  res.json({
    proxyHost: String(host),
    proxyPort,
    socks5Port,
    pacUrl: `${baseUrl}/api/ios/proxy.pac`,
    configUrl: `${baseUrl}/api/ios/config.mobileconfig`,
    socks5Stats: getSocks5Stats(),
  });
});

// POST /socks5/start — start SOCKS5 proxy
router.post("/socks5/start", async (_req, res) => {
  try {
    const stats = await startSocks5();
    res.json({ success: true, stats });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /socks5/stop — stop SOCKS5 proxy
router.post("/socks5/stop", (_req, res) => {
  const stats = stopSocks5();
  res.json({ success: true, stats });
});

// GET /socks5/status
router.get("/socks5/status", (_req, res) => {
  res.json(getSocks5Stats());
});

// GET /proxy.pac — Proxy Auto-Config file
router.get("/proxy.pac", (req, res) => {
  const rawHost = req.headers["x-forwarded-host"] || req.hostname;
  const proxyHost = String(rawHost).split(":")[0];
  const proxyPort = 18080;

  const pac = `function FindProxyForURL(url, host) {
  if (isPlainHostName(host)) return "DIRECT";
  if (shExpMatch(host, "192.168.*")) return "DIRECT";
  if (shExpMatch(host, "10.*")) return "DIRECT";
  if (shExpMatch(host, "127.*")) return "DIRECT";
  return "PROXY ${proxyHost}:${proxyPort}";
}`;

  res.setHeader("Content-Type", "application/x-ns-proxy-autoconfig");
  res.setHeader("Content-Disposition", 'inline; filename="proxy.pac"');
  res.send(pac);
});

// GET /config.mobileconfig — Apple Configuration Profile
router.get("/config.mobileconfig", (req, res) => {
  const rawHost = req.headers["x-forwarded-host"] || req.hostname;
  const host = String(rawHost).split(":")[0];
  const proxyPort = 18080;
  const protocol = req.headers["x-forwarded-proto"] || "https";
  const pacUrl = `${protocol}://${host}/api/ios/proxy.pac`;

  const uuid1 = generateUUID();
  const uuid2 = generateUUID();

  const mobileconfig = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadContent</key>
  <array>
    <dict>
      <key>PayloadDescription</key>
      <string>HTTP Proxy configuration for game traffic interception</string>
      <key>PayloadDisplayName</key>
      <string>Game Proxy (WiFi)</string>
      <key>PayloadIdentifier</key>
      <string>com.gameproxy.config.proxy.${uuid1}</string>
      <key>PayloadType</key>
      <string>com.apple.webClip.managed</string>
      <key>PayloadUUID</key>
      <string>${uuid1}</string>
      <key>PayloadVersion</key>
      <integer>1</integer>
      <key>Label</key>
      <string>Proxy Manager</string>
      <key>URL</key>
      <string>${protocol}://${host}</string>
      <key>IsRemovable</key>
      <true/>
      <key>FullScreen</key>
      <false/>
    </dict>
    <dict>
      <key>PayloadDescription</key>
      <string>Configures global HTTP proxy via PAC URL</string>
      <key>PayloadDisplayName</key>
      <string>HTTP Proxy (PAC)</string>
      <key>PayloadIdentifier</key>
      <string>com.gameproxy.config.proxies.${uuid2}</string>
      <key>PayloadType</key>
      <string>com.apple.proxy.http.global</string>
      <key>PayloadUUID</key>
      <string>${uuid2}</string>
      <key>PayloadVersion</key>
      <integer>1</integer>
      <key>ProxiesHTTPEnable</key>
      <integer>1</integer>
      <key>ProxiesHTTPProxy</key>
      <string>${host}</string>
      <key>ProxiesHTTPPort</key>
      <integer>${proxyPort}</integer>
      <key>ProxiesHTTPSEnable</key>
      <integer>1</integer>
      <key>ProxiesHTTPSProxy</key>
      <string>${host}</string>
      <key>ProxiesHTTPSPort</key>
      <integer>${proxyPort}</integer>
      <key>ProxiesProxyAutoConfigEnable</key>
      <integer>1</integer>
      <key>ProxiesProxyAutoConfigURLString</key>
      <string>${pacUrl}</string>
    </dict>
  </array>
  <key>PayloadDescription</key>
  <string>Routes device traffic through the Game Proxy and VPN Manager</string>
  <key>PayloadDisplayName</key>
  <string>Game Proxy & VPN Manager</string>
  <key>PayloadIdentifier</key>
  <string>com.gameproxy.config</string>
  <key>PayloadOrganization</key>
  <string>Game Proxy Manager</string>
  <key>PayloadRemovalDisallowed</key>
  <false/>
  <key>PayloadType</key>
  <string>Configuration</string>
  <key>PayloadUUID</key>
  <string>${generateUUID()}</string>
  <key>PayloadVersion</key>
  <integer>1</integer>
</dict>
</plist>`;

  res.setHeader("Content-Type", "application/x-apple-aspen-config; charset=utf-8");
  res.setHeader("Content-Disposition", 'attachment; filename="GameProxy.mobileconfig"');
  res.send(mobileconfig);
});

function generateUUID(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16).toUpperCase();
  });
}

export default router;
