import net from "net";
import { randomUUID } from "crypto";

export interface Socks5Stats {
  running: boolean;
  port: number | null;
  connections: number;
  bytesIn: number;
  bytesOut: number;
}

interface LogEntry {
  id: string;
  timestamp: string;
  target: string;
  bytesTransferred: number;
}

const SOCKS_PORT = 18081;

let server: net.Server | null = null;
const stats: Socks5Stats = {
  running: false,
  port: null,
  connections: 0,
  bytesIn: 0,
  bytesOut: 0,
};

export const socks5Logs: LogEntry[] = [];

function addLog(target: string, bytes: number) {
  socks5Logs.unshift({ id: randomUUID(), timestamp: new Date().toISOString(), target, bytesTransferred: bytes });
  if (socks5Logs.length > 200) socks5Logs.length = 200;
}

// SOCKS5 RFC 1928
function handleClient(socket: net.Socket) {
  stats.connections++;
  let state: "auth" | "request" | "relay" = "auth";
  let buf = Buffer.alloc(0);

  socket.on("data", (chunk: Buffer) => {
    buf = Buffer.concat([buf, chunk]);

    if (state === "auth") {
      // Greeting: VER(1) NMETHODS(1) METHODS(NMETHODS)
      if (buf.length < 2) return;
      const nmethods = buf[1];
      if (buf.length < 2 + nmethods) return;
      // Accept: no auth (0x00)
      socket.write(Buffer.from([0x05, 0x00]));
      buf = buf.slice(2 + nmethods);
      state = "request";
      return;
    }

    if (state === "request") {
      // Request: VER(1) CMD(1) RSV(1) ATYP(1) DST.ADDR DST.PORT(2)
      if (buf.length < 4) return;
      const cmd = buf[1];
      const atyp = buf[3];

      let host = "";
      let port = 0;
      let offset = 4;

      if (atyp === 0x01) {
        // IPv4
        if (buf.length < offset + 4 + 2) return;
        host = Array.from(buf.slice(offset, offset + 4)).join(".");
        offset += 4;
      } else if (atyp === 0x03) {
        // Domain
        if (buf.length < offset + 1) return;
        const len = buf[offset];
        offset += 1;
        if (buf.length < offset + len + 2) return;
        host = buf.slice(offset, offset + len).toString();
        offset += len;
      } else if (atyp === 0x04) {
        // IPv6
        if (buf.length < offset + 16 + 2) return;
        const parts: string[] = [];
        for (let i = 0; i < 16; i += 2) {
          parts.push(buf.slice(offset + i, offset + i + 2).toString("hex"));
        }
        host = parts.join(":");
        offset += 16;
      } else {
        socket.write(Buffer.from([0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
        socket.destroy();
        return;
      }

      port = buf.readUInt16BE(offset);
      const remaining = buf.slice(offset + 2);

      if (cmd !== 0x01) {
        // Only CONNECT supported
        socket.write(Buffer.from([0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
        socket.destroy();
        return;
      }

      const target = `${host}:${port}`;
      const upstream = net.connect(port, host, () => {
        // Success response
        socket.write(Buffer.from([0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
        // Send any buffered data
        if (remaining.length > 0) upstream.write(remaining);
        state = "relay";

        let bytes = 0;
        upstream.on("data", (d: Buffer) => {
          stats.bytesIn += d.length;
          bytes += d.length;
          socket.write(d);
        });
        socket.on("data", (d: Buffer) => {
          stats.bytesOut += d.length;
          upstream.write(d);
        });
        upstream.on("end", () => {
          addLog(target, bytes);
          socket.end();
        });
        upstream.on("error", () => socket.destroy());
      });

      upstream.on("error", () => {
        const errBuf = Buffer.from([0x05, 0x04, 0x00, 0x01, 0, 0, 0, 0, 0, 0]);
        socket.write(errBuf);
        socket.destroy();
      });

      buf = Buffer.alloc(0);
    }
  });

  socket.on("error", () => {});
  socket.on("close", () => { stats.connections = Math.max(0, stats.connections - 1); });
}

export function startSocks5(): Promise<Socks5Stats> {
  return new Promise((resolve, reject) => {
    if (server) {
      resolve({ ...stats });
      return;
    }
    server = net.createServer(handleClient);
    server.listen(SOCKS_PORT, "0.0.0.0", () => {
      stats.running = true;
      stats.port = SOCKS_PORT;
      stats.bytesIn = 0;
      stats.bytesOut = 0;
      stats.connections = 0;
      resolve({ ...stats });
    });
    server.on("error", (err: NodeJS.ErrnoException) => {
      if (err.code === "EADDRINUSE") {
        stats.running = true;
        stats.port = SOCKS_PORT;
        resolve({ ...stats });
      } else {
        reject(err);
      }
    });
  });
}

export function stopSocks5(): Socks5Stats {
  if (server) {
    server.close();
    server = null;
  }
  stats.running = false;
  stats.port = null;
  return { ...stats };
}

export function getSocks5Stats(): Socks5Stats {
  return { ...stats };
}
